export class Song {
    id:number;
    albumName:string;
    artistName:string;
    price:string;
}
