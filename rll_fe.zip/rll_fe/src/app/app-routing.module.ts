import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ViewfeedbackComponent } from './viewfeedback/viewfeedback.component';
import { SongListComponent } from './song-list/song-list.component';
import { CreateSongComponent } from './create-song/create-song.component';
import { UpdateSongComponent } from './update-song/update-song.component';
import { SongDetailsComponent } from './song-details/song-details.component';
import { LoginComponent } from './login/login.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [

  { path: 'Home', component: HomeComponent },
  { path: '', redirectTo: 'Home', pathMatch: 'full' },

  { path: 'Song List', component: SongListComponent },
  { path: 'update-song/:id', component: UpdateSongComponent },
  { path: 'song-details/:id', component: SongDetailsComponent },
  { path: 'Create Song', component: CreateSongComponent },

  { path: 'Contact Us', component: ContactComponent },

  { path: 'Feedback', component: FeedbackComponent },
  { path: 'View Feedback', component: ViewfeedbackComponent },

  {path:'loginsuccess', component: LoginsuccessComponent},
  {path:'registration', component: RegistrationComponent},
  {path:'login', component: LoginComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
