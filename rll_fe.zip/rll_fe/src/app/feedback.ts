export class Feedback
{
    constructor(
        public name:string,
        public email:string,
        public phoneno:string,
        public feedback:string

    ){}
}
