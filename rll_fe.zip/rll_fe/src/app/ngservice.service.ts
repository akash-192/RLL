import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NgserviceService {

    private basePath = 'http://localhost:8090/';
    constructor(private http:HttpClient) { }


    public saveContact(contact:any)
    {
        return this.http.post("http://localhost:8090/addcontact",contact,{responseType:"text" as "json"});
    }

    public saveFeedback(feedback:any)
    {
      return this.http.post("http://localhost:8090/addfeedback",feedback,{responseType:"text" as "json"});
    }
    
    fetchFeedbackListFromRemote(): Observable<any>
    {
      return this.http.get<any>("http://localhost:8090/getfeedback");
    }

    
}
