package com.product.crud.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.crud.model.Contact;
import com.product.crud.repo.ContactRepo;

import java.util.*;

@Service
public class ContactService {
  
	@Autowired
	private ContactRepo repo;
	public List<Contact> fetchContactList(){
	return repo.findAll();
 }
	
	
	public Contact saveContactToDB(Contact contact){
		return repo.save(contact);
	}
	
	
	
}