package com.product.crud.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "songs")
public class Song {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)				//changed from identity to sequence
	private long id;
	
	@Column(name = "album_name")
	private String albumName;

	@Column(name = "artist_name")
	private String artistName;
	
	@Column(name = "price")
	private String price;
	
public Song() {
		
	}

	public Song(String albumName, String artistName, String price) {
		super();
		this.albumName = albumName;
		this.artistName = artistName;
		this.price = price;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAlbumName() {
		return albumName;
	}
	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}
	public String getArtistName() {
		return artistName;
	}
	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
}