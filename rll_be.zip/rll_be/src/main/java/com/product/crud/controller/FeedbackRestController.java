package com.product.crud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

import com.product.crud.model.Feedback;
import com.product.crud.services.FeedbackService;

@RestController
public class FeedbackRestController {

		@Autowired
		private FeedbackService service;
		
		@CrossOrigin(origins="http://localhost:4200")
		@GetMapping("/getfeedback")
		public List<Feedback> fetchFeedbackList(){
			List<Feedback> feedbacks = new ArrayList<Feedback>();
			//Fetching the list from database
			feedbacks = service.fetchFeedbackList();
			return feedbacks;
		}
		
		//Adding feedback into database
		@PostMapping("/addfeedback")
		@CrossOrigin(origins="http://localhost:4200")
		public Feedback saveFeedback(@RequestBody Feedback feedback) {
			return service.saveFeedbackToDB(feedback);
		}
		
		
}
