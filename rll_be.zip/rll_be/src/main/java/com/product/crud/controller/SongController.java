package com.product.crud.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.product.crud.exception.ResourceNotFoundException;
import com.product.crud.model.Song;
import com.product.crud.repo.SongRepository;




@CrossOrigin(origins = "http://localhost:4200")
@RestController
//@RequestMapping("/api/v1/")
public class SongController {
	
	@Autowired
	private SongRepository songRepository;
	
	// get all songs
	@GetMapping("/songs")
	public List<Song> getAllSongs(){
		return songRepository.findAll();
	}		
	
	// create song rest api
		@PostMapping("/songs")
		public Song createSong(@RequestBody Song song) {
			return songRepository.save(song);
			}
		
		// get song by id rest api
			@GetMapping("/songs/{id}")
			public ResponseEntity<Song> getSongById(@PathVariable Long id) {
				Song song = songRepository.findById(id)
						.orElseThrow(() -> new ResourceNotFoundException("Song not exist with id :" + id));
				return ResponseEntity.ok(song);
			}
			
			//update song by rest api
			@PutMapping("/songs/{id}")
			public ResponseEntity<Song> updateSong(@PathVariable Long id, @RequestBody Song songDetails){
				Song song = songRepository.findById(id)
						.orElseThrow(() -> new ResourceNotFoundException("Song not exist with id :" + id));
				
				song.setAlbumName(songDetails.getAlbumName());
				song.setArtistName(songDetails.getArtistName());
				song.setPrice(songDetails.getPrice());
				
				Song updatedSong = songRepository.save(song);
				return ResponseEntity.ok(updatedSong);
			}
			
			// delete song rest api
			@DeleteMapping("/songs/{id}")
			public ResponseEntity<Map<String, Boolean>> deleteSong(@PathVariable Long id){
				Song song = songRepository.findById(id)
						.orElseThrow(() -> new ResourceNotFoundException("Song not exist with id :" + id));
				
				songRepository.delete(song);
				Map<String, Boolean> response = new HashMap<>();
				response.put("deleted", Boolean.TRUE);
				return ResponseEntity.ok(response);
			}

}
