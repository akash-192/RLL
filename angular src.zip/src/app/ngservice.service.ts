import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NgserviceService {

    private basePath = 'http://localhost:8090/';
    constructor(private http:HttpClient) { }


    public saveContact(contact:any)
    {
        return this.http.post("http://localhost:8090/addcontact",contact,{responseType:"text" as "json"});
    }

    
}
