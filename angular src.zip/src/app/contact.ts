export class Contact
{
    constructor(
        public id:number,
        public name:string,
        public phone:string,
        public email:string,
        public message:string

    ){}
}
