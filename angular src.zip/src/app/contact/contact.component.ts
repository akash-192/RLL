import { Component, OnInit } from '@angular/core';
import { NgserviceService } from '../ngservice.service';
import { Contact } from '../contact'; 

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  users:Contact=new Contact(0,"","","","");
  message:any;

  constructor(private service:NgserviceService) { }

  ngOnInit(): void {
  }


  public addcontact()
  {
    let response=this.service.saveContact(this.users);
    response.subscribe(data=>
      {  alert("Thank you");
    });
  }

}
